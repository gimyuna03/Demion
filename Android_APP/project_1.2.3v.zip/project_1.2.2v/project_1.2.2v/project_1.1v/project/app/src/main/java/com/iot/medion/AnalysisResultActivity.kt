package com.iot.medion

import android.content.ContentValues
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class AnalysisResultActivity : AppCompatActivity() {

    private var currentRecordId: Long = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_analysis_result)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        currentRecordId = intent.getLongExtra("RECORD_ID", -1L)
        val currentUserId = intent.getLongExtra("USER_ID", -1L)

        if (currentRecordId == -1L || currentUserId == -1L) {
            Toast.makeText(this, "오류: 진단 기록을 불러올 수 없습니다.", Toast.LENGTH_LONG).show()
            finish()
            return
        }

        // --- (가상) AI 분석 결과 저장 ---
        // (실제로는 여기서 AI 모델을 돌리거나 서버에서 결과를 받아옵니다)
        saveAiResult(currentRecordId)
        // --- UI 요소들을 찾아옵니다. ---
        // val analysisResultTitle = findViewById<TextView>(R.id.analysisResultTitle)
        // ... (다른 TextView들) ...
        val buttonConfirm = findViewById<Button>(R.id.buttonConfirm) // '확인' 버튼 찾아오기

        // --- '확인' 버튼 클릭 이벤트 처리 ---
        buttonConfirm.setOnClickListener {
            val intent = Intent(this@AnalysisResultActivity, OptionActivity::class.java)
            intent.putExtra("USER_ID", currentUserId)
            startActivity(intent)
            finish() // 분석 결과 화면은 종료하고 OptionActivity로 넘어갑니다.
        }
    }

    // (가상) AI 분석 결과를 AIResultDB에 저장하는 함수
    private fun saveAiResult(recordId: Long) {
        // --- 가상의 AI 분석 결과 데이터 ---
        val cnnResult = "상처 부위 감염 의심 (78%)"
        val diseaseCandidates = """
            [
                {"name": "봉와직염", "probability": 0.78},
                {"name": "단순 타박상", "probability": 0.15},
                {"name": "알레르기성 피부염", "probability": 0.07}
            ]
        """.trimIndent() // (JSON 형태의 문자열)
        val finalDiagnosis = "초기 봉와직염 가능성"
        val feedback = "가까운 병원을 방문하여 전문의의 진단을 받는 것을 권장합니다."
        // ---------------------------------

        val dbHelper = DatabaseHelper(this)
        val db = dbHelper.writableDatabase

        val values = ContentValues().apply {
            put(DatabaseHelper.AIResultDBEntry.COLUMN_RECORD_ID, recordId)
            put(DatabaseHelper.AIResultDBEntry.COLUMN_CNN_RESULT, cnnResult)
            put(DatabaseHelper.AIResultDBEntry.COLUMN_DISEASE_CANDIDATES, diseaseCandidates)
            put(DatabaseHelper.AIResultDBEntry.COLUMN_FINAL_DIAGNOSIS, finalDiagnosis)
            put(DatabaseHelper.AIResultDBEntry.COLUMN_FEEDBACK, feedback)
        }

        try {
            // AIResultDB에 INSERT
            db.insert(DatabaseHelper.AIResultDBEntry.TABLE_NAME, null, values)
            // (이후 이 데이터를 화면의 TextView들에 표시해야 함)
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(this, "AI 결과 저장 중 오류 발생", Toast.LENGTH_SHORT).show()
        } finally {
            db.close()
        }
    }
}