package com.iot.medion

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.provider.BaseColumns

class DatabaseHelper(context: Context) :
        SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    object UserDBEntry : BaseColumns {
        const val TABLE_NAME = "UserDB"
        const val COLUMN_USER_ID = "user_id" // (INTEGER, PK)
        const val COLUMN_USERNAME = "username" // (TEXT)
        const val COLUMN_PASSWORD = "password" // (TEXT)
        const val COLUMN_AGE = "age" // (INTEGER)
        const val COLUMN_GENDER = "gender" // (TEXT)
        const val COLUMN_CREATED_AT = "created_at" // (DATETIME)
    }

    object HealthRecordDBEntry : BaseColumns {
        const val TABLE_NAME = "HealthRecordDB"
        const val COLUMN_RECORD_ID = "record_id" // (INTEGER, PK)
        const val COLUMN_USER_ID = "user_id" // (INTEGER, FK)
        const val COLUMN_IMAGE_PATH = "image_path" // (TEXT)
        const val COLUMN_SYMPTOM = "symptom" // (TEXT)
        const val COLUMN_PAIN_LEVEL = "pain_level" // (INTEGER)
        const val COLUMN_TEMPERATURE = "temperature" // (REAL)
        const val COLUMN_CREATED_AT = "created_at" // (DATETIME)
        const val COLUMN_SYMPTOMS = "symptoms"
        const val COLUMN_TIMESTAMP = "timestamp"
    }

    object AIResultDBEntry : BaseColumns {
        const val TABLE_NAME = "AIResultDB"
        const val COLUMN_RESULT_ID = "result_id" // (INTEGER, PK)
        const val COLUMN_RECORD_ID = "record_id" // (INTEGER, FK)
        const val COLUMN_CNN_RESULT = "cnn_result" // (TEXT)
        const val COLUMN_DISEASE_CANDIDATES = "disease_candidates" // (TEXT)
        const val COLUMN_FINAL_DIAGNOSIS = "final_diagnosis" // (TEXT)
        const val COLUMN_FEEDBACK = "feedback" // (TEXT)
    }

    companion object {
        const val DATABASE_VERSION = 2
        const val DATABASE_NAME = "Medion.db"
        // --- 테이블 생성 SQL 문 ---

        // 1. UserDB 생성
        // (user_id는 BaseColumns의 _ID를 사용하지 않고 명세서대로 명시적 PK 사용)
        private const val SQL_CREATE_USERDB =
            "CREATE TABLE ${UserDBEntry.TABLE_NAME} (" +
                    "${UserDBEntry.COLUMN_USER_ID} INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "${UserDBEntry.COLUMN_USERNAME} TEXT NOT NULL, " +
                    "${UserDBEntry.COLUMN_PASSWORD} TEXT NOT NULL, " + // 실제로는 암호화된 값을 저장해야 함
                    "${UserDBEntry.COLUMN_AGE} INTEGER, " +
                    "${UserDBEntry.COLUMN_GENDER} TEXT, " +
                    "${UserDBEntry.COLUMN_CREATED_AT} TEXT DEFAULT CURRENT_TIMESTAMP)"

        // 2. HealthRecordDB 생성
        private const val SQL_CREATE_HEALTHRECORDDB =
            "CREATE TABLE ${HealthRecordDBEntry.TABLE_NAME} (" +
                    "${HealthRecordDBEntry.COLUMN_RECORD_ID} INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "${HealthRecordDBEntry.COLUMN_USER_ID} INTEGER NOT NULL, " +
                    "${HealthRecordDBEntry.COLUMN_IMAGE_PATH} TEXT, " +
                    "${HealthRecordDBEntry.COLUMN_SYMPTOM} TEXT, " +
                    "${HealthRecordDBEntry.COLUMN_PAIN_LEVEL} INTEGER, " +
                    "${HealthRecordDBEntry.COLUMN_TEMPERATURE} REAL, " +
                    "${HealthRecordDBEntry.COLUMN_CREATED_AT} TEXT DEFAULT CURRENT_TIMESTAMP, " +
                    "FOREIGN KEY(${HealthRecordDBEntry.COLUMN_USER_ID}) REFERENCES " +
                    "${UserDBEntry.TABLE_NAME}(${UserDBEntry.COLUMN_USER_ID}) ON DELETE CASCADE)" // UserDB가 삭제되면 관련 레코드도 삭제

        // 3. AIResultDB 생성
        // (설명서: "각 진단 기록은 하나의 AI 분석 결과와 연결된다" -> record_id에 UNIQUE 제약 추가)
        private const val SQL_CREATE_AIRESULTDB =
            "CREATE TABLE ${AIResultDBEntry.TABLE_NAME} (" +
                    "${AIResultDBEntry.COLUMN_RESULT_ID} INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "${AIResultDBEntry.COLUMN_RECORD_ID} INTEGER NOT NULL UNIQUE, " +
                    "${AIResultDBEntry.COLUMN_CNN_RESULT} TEXT, " +
                    "${AIResultDBEntry.COLUMN_DISEASE_CANDIDATES} TEXT, " +
                    "${AIResultDBEntry.COLUMN_FINAL_DIAGNOSIS} TEXT, " +
                    "${AIResultDBEntry.COLUMN_FEEDBACK} TEXT, " +
                    "FOREIGN KEY(${AIResultDBEntry.COLUMN_RECORD_ID}) REFERENCES " +
                    "${HealthRecordDBEntry.TABLE_NAME}(${HealthRecordDBEntry.COLUMN_RECORD_ID}) ON DELETE CASCADE)" // HealthRecordDB가 삭제되면 관련 레코드도 삭제

    }
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("PRAGMA foreign_keys=ON;")

        // 테이블 생성
        db.execSQL(SQL_CREATE_USERDB)
        db.execSQL(SQL_CREATE_HEALTHRECORDDB)
        db.execSQL(SQL_CREATE_AIRESULTDB)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS ${AIResultDBEntry.TABLE_NAME}")
        db.execSQL("DROP TABLE IF EXISTS ${HealthRecordDBEntry.TABLE_NAME}")
        db.execSQL("DROP TABLE IF EXISTS ${UserDBEntry.TABLE_NAME}")
        onCreate(db)
    }

    override fun onOpen(db: SQLiteDatabase) {
        super.onOpen(db)
        if (!db.isReadOnly) {
            db.execSQL("PRAGMA foreign_keys=ON;")
        }
    }
}
