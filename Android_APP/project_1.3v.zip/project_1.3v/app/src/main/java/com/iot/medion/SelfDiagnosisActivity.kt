package com.iot.medion

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import android.util.Log

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import kotlin.random.Random // kotlin.random.Random 명시적 import
import android.widget.Toast
import android.content.Intent
import android.content.ContentValues
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import android.provider.MediaStore // 갤러리 인텐트 사용
import android.widget.ImageView
import android.net.Uri

class SelfDiagnosisActivity : AppCompatActivity() {

    private lateinit var pickImageLauncher: ActivityResultLauncher<Intent> // 갤러리 이미지 선택 인텐트
    private var currentUserId: Long = -1
    private var currentTemperature: Double = 0.0
    private var currentImagePath: String? = null // 선택된 이미지의 URI (문자열 형태)

    private lateinit var imageViewPhotoPreview: ImageView

    // 권한 요청을 처리할 requestCode (상수)
    private val REQUEST_BLUETOOTH_PERMISSIONS = 1

    // 블루투스 활성화 요청을 처리할 Launcher (사용 안 할 경우 제거 가능)
    private lateinit var enableBtLauncher: ActivityResultLauncher<Intent> // TODO: 이 런처가 어디선가 초기화 및 사용되어야 함 (현재 코드에서는 사용되지 않음)

    // TFLite 관련 변수 (AI 기능을 사용한다면 추가)
    // private var imageClassifier: ImageClassifier? = null
    // private val MODEL_FILE_NAME = "mobilenet_v1_1.0_224_quant.tflite" // 사용할 TFLite 모델 파일명

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_self_diagnosis)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // --- onCreate 시작 시 블루투스 권한 확인 및 요청 ---
        checkBluetoothPermissions()
        // --- TFLite 모델 초기화 --- (만약 AI 기능을 다시 추가한다면 여기에)
        // initImageClassifier()

        currentUserId = intent.getLongExtra("USER_ID", -1L)

        if (currentUserId == -1L) {
            Toast.makeText(this, "오류: 사용자 정보를 불러올 수 없습니다.", Toast.LENGTH_LONG).show()
            finish()
            return
        }

        imageViewPhotoPreview = findViewById(R.id.imageViewPhotoPreview)

        // --- 갤러리 이미지 선택을 위한 ActivityResultLauncher 초기화 ---
        pickImageLauncher =
            registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
                if (result.resultCode == RESULT_OK) { // 이미지를 성공적으로 선택했을 때
                    val imageUri = result.data?.data // 선택된 이미지의 URI를 가져옵니다.
                    if (imageUri != null) {
                        Toast.makeText(this, "사진이 성공적으로 선택되었습니다!", Toast.LENGTH_SHORT).show()
                        currentImagePath = imageUri.toString() // URI를 문자열로 저장합니다.

                        imageViewPhotoPreview.setImageURI(imageUri) // 선택된 이미지의 URI를 ImageView에 설정
                        imageViewPhotoPreview.visibility = View.VISIBLE // 미리보기 ImageView를 보이도록 변경

                        // --- AI 분석 코드를 다시 추가할 때 이 부분에 넣을 것 ---
                        // imageClassifier?.let { classifier ->
                        //    try {
                        //        var bitmap: Bitmap
                        //        // ... (비트맵 로드 및 ARGB_8888 변환 코드)
                        //        // val results = classifier.classify(bitmap)
                        //        // ... (결과 처리)
                        //    } catch (e: Exception) {
                        //        Log.e("TFLite", "이미지 분류 중 오류 발생: ${e.message}", e)
                        //        Toast.makeText(this, "AI 분석 중 오류 발생: ${e.message}", Toast.LENGTH_LONG).show()
                        //    }
                        // }
                        // -----------------------------------------------

                    } else {
                        Toast.makeText(this, "사진을 가져오지 못했습니다.", Toast.LENGTH_SHORT).show()
                    }
                } else if (result.resultCode == RESULT_CANCELED) { // 사용자가 이미지 선택을 취소했을 때
                    Toast.makeText(this, "사진 선택을 취소했습니다.", Toast.LENGTH_SHORT).show()
                }
            }

        // 1. UI 요소들을 찾아옵니다.
        val buttonMeasureTemperature = findViewById<Button>(R.id.buttonMeasureTemperature)
        val textViewTemperatureValue = findViewById<TextView>(R.id.textViewTemperatureValue)
        val buttonSubmitDiagnosis = findViewById<Button>(R.id.buttonSubmitDiagnosis)
        val loadingLayout = findViewById<LinearLayout>(R.id.loadingLayout)
        val buttonSelectPhoto = findViewById<Button>(R.id.buttonSelectPhoto)

        // 2. '온도 측정' 버튼 클릭 이벤트 처리
        buttonMeasureTemperature.setOnClickListener {
            val randomTemperature = kotlin.random.Random.nextDouble(36.0, 40.0) // kotlin.random.Random 사용
            currentTemperature = randomTemperature
            val formattedTemperature = String.format("%.2f", randomTemperature)
            textViewTemperatureValue.text = "현재 온도: $formattedTemperature °C"
        }

        // 3. '사진 선택' 버튼 클릭 이벤트 처리 (이제 카메라 대신 갤러리에서 선택)
        buttonSelectPhoto.setOnClickListener {
            // 갤러리 앱을 열어 이미지를 선택하게 하는 인텐트
            val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
            pickImageLauncher.launch(intent) // 갤러리 앱 실행
        }

        // 4. '기록 제출' 버튼 클릭 이벤트 처리 (로딩 창을 보여주는 핵심 로직)
        buttonSubmitDiagnosis.setOnClickListener {
            Log.d("DiagnosisFlow", "기록 제출 버튼 클릭됨.")

            val tempSymptom = "증상 입력 없음"
            val tempPainLevel = 5

            if (currentTemperature == 0.0) {
                Toast.makeText(this, "온도를 먼저 측정해주세요.", Toast.LENGTH_SHORT).show()
                Log.d("DiagnosisFlow", "온도 미측정, 중단.")
                return@setOnClickListener
            }
            if (currentImagePath == null) {
                Toast.makeText(this, "사진을 먼저 선택해주세요.", Toast.LENGTH_SHORT).show()
                Log.d("DiagnosisFlow", "사진 미선택, 중단.")
                return@setOnClickListener
            }

            loadingLayout.visibility = View.VISIBLE
            Log.d("DiagnosisFlow", "로딩 화면 표시 및 3초 대기 시작.")

            Handler(Looper.getMainLooper()).postDelayed({
                Log.d("DiagnosisFlow", "3초 대기 후 DB 저장 로직 시작.")

                val dbHelper = DatabaseHelper(this@SelfDiagnosisActivity)
                val db = dbHelper.writableDatabase

                val values = ContentValues().apply {
                    put(DatabaseHelper.HealthRecordDBEntry.COLUMN_USER_ID, currentUserId)
                    put(DatabaseHelper.HealthRecordDBEntry.COLUMN_IMAGE_PATH, currentImagePath) // URI 문자열 저장
                    put(DatabaseHelper.HealthRecordDBEntry.COLUMN_SYMPTOMS, tempSymptom) // COLUMN_SYMPTOM -> COLUMN_SYMPTOMS로 수정 (혹시모를 오타대비)
                    put(DatabaseHelper.HealthRecordDBEntry.COLUMN_PAIN_LEVEL, tempPainLevel)
                    put(DatabaseHelper.HealthRecordDBEntry.COLUMN_TEMPERATURE, currentTemperature)
                    put(DatabaseHelper.HealthRecordDBEntry.COLUMN_TIMESTAMP, System.currentTimeMillis()) // timestamp 추가
                }

                val newRecordId = db.insert(DatabaseHelper.HealthRecordDBEntry.TABLE_NAME, null, values)
                db.close()
                Log.d("DiagnosisFlow", "DB 저장 완료. newRecordId: $newRecordId")

                loadingLayout.visibility = View.GONE

                if (newRecordId == -1L) {
                    Toast.makeText(this@SelfDiagnosisActivity, "진단 기록 저장에 실패했습니다.", Toast.LENGTH_SHORT).show()
                    Log.e("DiagnosisFlow", "DB 저장 실패, AnalysisResultActivity로 이동 안함.")
                } else {
                    Toast.makeText(this@SelfDiagnosisActivity, "분석이 완료되었습니다!", Toast.LENGTH_SHORT).show()
                    val intent = Intent(this@SelfDiagnosisActivity, AnalysisResultActivity::class.java)
                    intent.putExtra("RECORD_ID", newRecordId)
                    intent.putExtra("USER_ID", currentUserId)
                    intent.putExtra("IMAGE_URI", currentImagePath) // <-- 이미지 URI를 AnalysisResultActivity로 전달!

                    Log.d("DiagnosisFlow", "AnalysisResultActivity로 이동 시작!")
                    startActivity(intent)
                    finish()
                }
            }, 3000)
        }
    } // <- onCreate 메서드는 여기서 닫힙니다!


    // --- 이제 모든 함수는 onCreate() 메서드 바깥, SelfDiagnosisActivity 클래스 안에 위치해야 합니다. ---

    // --- 블루투스 권한 확인 및 요청 함수 ---
    private fun checkBluetoothPermissions() {
        val permissionsToRequest = ArrayList<String>()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(Manifest.permission.BLUETOOTH_SCAN)
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(Manifest.permission.BLUETOOTH_CONNECT)
            }
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(Manifest.permission.ACCESS_FINE_LOCATION)
            }
        }

        if (permissionsToRequest.isNotEmpty()) {
            ActivityCompat.requestPermissions(
                this,
                permissionsToRequest.toTypedArray(),
                REQUEST_BLUETOOTH_PERMISSIONS
            )
        } else {
            startBluetoothOperations()
        }
    }

    // --- 권한 요청 결과 처리 함수 ---
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_BLUETOOTH_PERMISSIONS) {
            var allPermissionsGranted = true
            for (result in grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    allPermissionsGranted = false
                    break
                }
            }

            if (allPermissionsGranted) {
                Toast.makeText(this, "블루투스 권한이 모두 허용되었습니다.", Toast.LENGTH_SHORT).show()
                startBluetoothOperations()
            } else {
                Toast.makeText(this, "블루투스 권한이 거부되어 기능을 사용할 수 없습니다.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // --- 모든 블루투스 권한이 허용된 후 실행할 함수 ---
    private fun startBluetoothOperations() {
        Toast.makeText(this, "블루투스 기능 준비 완료!", Toast.LENGTH_SHORT).show()
        // 여기에 실제 블루투스 기기 스캔 및 연결 로직을 시작할 수 있습니다.
    }

    // --- TFLite 모델 초기화 함수 (AI 기능을 사용한다면 추가) ---
    /*
    private fun initImageClassifier() {
        try {
            imageClassifier = ImageClassifier(this, MODEL_FILE_NAME)
            Log.d("TFLite", "ImageClassifier 초기화 성공")
        } catch (e: IOException) {
            Log.e("TFLite", "ImageClassifier 초기화 실패: ${e.message}", e)
            Toast.makeText(this, "AI 모델 로드 실패: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        imageClassifier?.close()
    }
    */

} // <- SelfDiagnosisActivity 클래스의 닫는 중괄호!