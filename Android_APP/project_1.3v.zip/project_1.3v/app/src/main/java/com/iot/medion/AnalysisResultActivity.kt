package com.iot.medion // Master 학생의 실제 패키지명으로 변경해주세요!

import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View // View import 추가
import android.widget.Button
import android.widget.ImageView // ImageView import 추가
import android.widget.TextView // TextView import 추가
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.util.Log // Logcat 사용을 위해 추가

class AnalysisResultActivity : AppCompatActivity() {

    // UI 요소 선언 - 클래스 멤버 변수로 선언하여 onCreate 외부에서도 접근 가능하게 함
    private lateinit var analysisResultTitle: TextView // 누락된 TextView 연결
    private lateinit var imageViewWoundPhoto: ImageView
    private lateinit var textViewDiseaseDesc: TextView // 누락된 TextView 연결
    private lateinit var textViewSymptomStatus: TextView // 누락된 TextView 연결
    private lateinit var textViewSolution: TextView // 누락된 TextView 연결
    private lateinit var buttonConfirm: Button

    private var currentRecordId: Long = -1 // DB 레코드 ID
    private var currentUserId: Long = -1   // 현재 사용자 ID

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_analysis_result)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // --- 1. UI 요소들을 XML ID와 연결 ---
        // Master 학생이 XML에 정의한 ID와 정확히 일치하는지 확인해주세요!
        analysisResultTitle = findViewById(R.id.analysisResultTitle)
        imageViewWoundPhoto = findViewById(R.id.imageViewWoundPhoto)
        textViewDiseaseDesc = findViewById(R.id.textViewDiseaseDesc)
        textViewSymptomStatus = findViewById(R.id.textViewSymptomStatus)
        textViewSolution = findViewById(R.id.textViewSolution)
        buttonConfirm = findViewById(R.id.buttonConfirm)

        // --- 2. Intent에서 전달받은 데이터 확인 ---
        currentRecordId = intent.getLongExtra("RECORD_ID", -1L)
        currentUserId = intent.getLongExtra("USER_ID", -1L)
        val imageUriString = intent.getStringExtra("IMAGE_URI") // 'IMAGE_URI' 키로 Master 학생의 SelfDiagnosisActivity에서 보냅니다.

        // 필수 데이터 누락 시 오류 처리
        if (currentRecordId == -1L || currentUserId == -1L || imageUriString == null) {
            Toast.makeText(this, "오류: 분석 결과를 불러올 수 없습니다. 다시 시도해주세요.", Toast.LENGTH_LONG).show()
            Log.e("AnalysisResult", "필수 데이터 누락: recordId=$currentRecordId, userId=$currentUserId, imageUri=$imageUriString")
            finish()
            return
        }

        // --- 3. 받은 이미지 URI를 ImageView에 표시 ---
        try {
            val imageUri = Uri.parse(imageUriString)
            imageViewWoundPhoto.setImageURI(imageUri)
            imageViewWoundPhoto.visibility = View.VISIBLE // 이미지가 잘 안 보일 경우 대비
            Log.d("AnalysisResult", "이미지 URI 로드 성공: $imageUriString")
        } catch (e: Exception) {
            Toast.makeText(this, "오류: 이미지 로딩에 실패했습니다.", Toast.LENGTH_LONG).show()
            Log.e("AnalysisResult", "이미지 로딩 오류: ${e.message}", e)
            // 에러 시 기본 이미지 설정 또는 ImageView 숨기기
            imageViewWoundPhoto.visibility = View.GONE
        }

        // --- 4. (TODO) DB에서 currentRecordId로 상세 정보를 불러와 UI 업데이트 ---
        // 이 부분에서 DatabaseHelper를 사용하여 currentRecordId에 해당하는 진단 기록 데이터를 DB에서 조회하고,
        // 조회된 데이터를 바탕으로 analysisResultTitle, textViewDiseaseDesc,
        // textViewSymptomStatus, textViewSolution 등의 TextView 내용을 업데이트하는 로직을 구현하세요.

        // 예시: (현재는 임시 텍스트를 표시하고 있습니다. 실제 DB 로드 후 교체)
        analysisResultTitle.text = "분석 결과 (기록 ID: $currentRecordId, 사용자 ID: $currentUserId)"
        textViewDiseaseDesc.text = "이곳에 DB에서 로드한 예상 질병 설명이 표시됩니다.\n지금은 DB 연결 전입니다."
        textViewSymptomStatus.text = "[ 상태 로드 필요 ]"
        textViewSolution.text = "이곳에 DB에서 로드한 증상 처치 및 솔루션이 표시됩니다.\n지금은 DB 연결 전입니다."


        // --- 5. AI 분석 결과 DB 저장 (onCreate에서는 직접 호출하지 않습니다. 필요한 시점에 호출) ---
        // saveAiResult(currentRecordId) // AI 결과 저장 로직이 여기에 있다면 호출할 수 있지만, 일반적으로 AI 분석 직후 SelfDiagnosisActivity에서 처리하는 것이 좋습니다.


        // --- 6. "확인" 버튼 클릭 시 동작 ---
        buttonConfirm.setOnClickListener {
            // OptionActivity로 돌아가는 인텐트를 생성
            val nextIntent = Intent(this, OptionActivity::class.java) // Master 학생의 'OptionActivity'로 가정
            nextIntent.putExtra("USER_ID", currentUserId) // 사용자 ID를 다음 화면으로 전달
            // 이전 액티비티 스택을 모두 지우고 새 작업을 시작하여
            // 사용자가 뒤로 가기 버튼을 눌렀을 때 현재 액티비티로 돌아오지 않게 합니다.
            nextIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(nextIntent)
            finish() // 현재 AnalysisResultActivity를 종료
        }

    } // onCreate 메서드의 끝

    // --- (가상) AI 분석 결과를 AIResultDB에 저장하는 함수 ---
    // 이 함수는 일반적으로 AI 분석이 완료된 직후인 SelfDiagnosisActivity에서 호출되거나,
    // AnalysisResultActivity의 경우 currentRecordId로 이미 저장된 데이터를 불러오는 형태로 사용됩니다.
    // 현재는 onCreate에서 직접 호출하기보다는, 참고용으로 클래스 내부에 정의해둡니다.
    private fun saveAiResult(recordId: Long) {
        // --- 가상의 AI 분석 결과 데이터 ---
        val cnnResult = "상처 부위 감염 의심 (78%)"
        val diseaseCandidates = """
            [
                {"name": "봉와직염", "probability": 0.78},
                {"name": "단순 타박상", "probability": 0.15},
                {"name": "알레르기성 피부염", "probability": 0.07}
            ]
        """.trimIndent() // (JSON 형태의 문자열)
        val finalDiagnosis = "초기 봉와직염 가능성"
        val feedback = "가까운 병원을 방문하여 전문의의 진단을 받는 것을 권장합니다."
        // ---------------------------------

        val dbHelper = DatabaseHelper(this)
        val db = dbHelper.writableDatabase

        val values = ContentValues().apply {
            put(DatabaseHelper.AIResultDBEntry.COLUMN_RECORD_ID, recordId)
            put(DatabaseHelper.AIResultDBEntry.COLUMN_CNN_RESULT, cnnResult)
            put(DatabaseHelper.AIResultDBEntry.COLUMN_DISEASE_CANDIDATES, diseaseCandidates)
            put(DatabaseHelper.AIResultDBEntry.COLUMN_FINAL_DIAGNOSIS, finalDiagnosis)
            put(DatabaseHelper.AIResultDBEntry.COLUMN_FEEDBACK, feedback)
        }

        try {
            val newAiRecordId = db.insert(DatabaseHelper.AIResultDBEntry.TABLE_NAME, null, values)
            if (newAiRecordId != -1L) {
                Log.d("AnalysisResult", "AI 결과 DB 저장 성공. AI Record ID: $newAiRecordId")
            } else {
                Log.e("AnalysisResult", "AI 결과 DB 저장 실패. recordId: $recordId")
            }
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(this, "AI 결과 저장 중 오류 발생", Toast.LENGTH_SHORT).show()
            Log.e("AnalysisResult", "AI 결과 DB 저장 오류: ${e.message}", e)
        } finally {
            db.close()
        }
    }
} // <--- AnalysisResultActivity 클래스의 끝