package com.iot.medion

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import android.util.Log

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import kotlin.random.Random
import android.widget.Toast
import android.content.Intent
import android.content.ContentValues
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import android.provider.MediaStore // 갤러리 인텐트 사용
import android.widget.ImageView
import android.net.Uri

// [중요!] 외부 저장소(갤러리) 접근 권한을 AndroidManifest.xml에 추가해야 합니다.
// <uses-permission android android:name="android.permission.READ_MEDIA_IMAGES" /> (Android 13/API 33 이상)
// <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32" /> (Android 12/API 32 이하)

class SelfDiagnosisActivity : AppCompatActivity() {

    private lateinit var pickImageLauncher: ActivityResultLauncher<Intent> // 갤러리 이미지 선택 인텐트
    private var currentUserId: Long = -1
    private var currentTemperature: Double = 0.0
    private var currentImagePath: String? = null // 선택된 이미지의 URI (문자열 형태)

    private lateinit var imageViewPhotoPreview: ImageView

    // 권한 요청을 처리할 requestCode (상수)
    private val REQUEST_BLUETOOTH_PERMISSIONS = 1

    // 블루투스 활성화 요청을 처리할 Launcher
    private lateinit var enableBtLauncher: ActivityResultLauncher<Intent>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_self_diagnosis)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        currentUserId = intent.getLongExtra("USER_ID", -1L)

        if (currentUserId == -1L) {
            Toast.makeText(this, "오류: 사용자 정보를 불러올 수 없습니다.", Toast.LENGTH_LONG).show()
            finish()
            return
        }

        imageViewPhotoPreview = findViewById(R.id.imageViewPhotoPreview)

        // --- 갤러리 이미지 선택을 위한 ActivityResultLauncher 초기화 ---
        pickImageLauncher =
            registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
                if (result.resultCode == RESULT_OK) { // 이미지를 성공적으로 선택했을 때
                    val imageUri = result.data?.data // 선택된 이미지의 URI를 가져옵니다.
                    if (imageUri != null) {
                        Toast.makeText(this, "사진이 성공적으로 선택되었습니다!", Toast.LENGTH_SHORT).show()
                        currentImagePath = imageUri.toString() // URI를 문자열로 저장합니다.

                        imageViewPhotoPreview.setImageURI(imageUri) // 선택된 이미지의 URI를 ImageView에 설정
                        imageViewPhotoPreview.visibility = View.VISIBLE // 미리보기 ImageView를 보이도록 변경

                    } else {
                        Toast.makeText(this, "사진을 가져오지 못했습니다.", Toast.LENGTH_SHORT).show()
                    }
                } else if (result.resultCode == RESULT_CANCELED) { // 사용자가 이미지 선택을 취소했을 때
                    Toast.makeText(this, "사진 선택을 취소했습니다.", Toast.LENGTH_SHORT).show()
                }
            }

        // 1. UI 요소들을 찾아옵니다.
        val buttonMeasureTemperature = findViewById<Button>(R.id.buttonMeasureTemperature)
        val textViewTemperatureValue = findViewById<TextView>(R.id.textViewTemperatureValue)
        val buttonSubmitDiagnosis = findViewById<Button>(R.id.buttonSubmitDiagnosis)
        val loadingLayout = findViewById<LinearLayout>(R.id.loadingLayout)
        val buttonSelectPhoto = findViewById<Button>(R.id.buttonSelectPhoto)

        // 2. '온도 측정' 버튼 클릭 이벤트 처리
        buttonMeasureTemperature.setOnClickListener {
            val randomTemperature = Random.nextDouble(36.0, 40.0) // 36.0 이상 40.0 미만의 랜덤 실수 생성
            currentTemperature = randomTemperature
            val formattedTemperature = String.format("%.2f", randomTemperature)
            textViewTemperatureValue.text = "현재 온도: $formattedTemperature °C"
        }

        // 3. '사진 선택' 버튼 클릭 이벤트 처리 (이제 카메라 대신 갤러리에서 선택)
        buttonSelectPhoto.setOnClickListener {
            // 갤러리 앱을 열어 이미지를 선택하게 하는 인텐트
            val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
            pickImageLauncher.launch(intent) // 갤러리 앱 실행
        }

        // 4. '기록 제출' 버튼 클릭 이벤트 처리 (로딩 창을 보여주는 핵심 로직)
        buttonSubmitDiagnosis.setOnClickListener {
            // (현재 증상(symptom), 통증척도(pain_level) UI가 없으므로 임시값 사용)
            val tempSymptom = "증상 입력 없음"
            val tempPainLevel = 5 // (1~10)

            // (온도를 측정하지 않았거나 사진을 선택하지 않았을 때의 유효성 검사가 필요합니다)
            if (currentTemperature == 0.0) {
                Toast.makeText(this, "온도를 먼저 측정해주세요.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (currentImagePath == null) {
                Toast.makeText(this, "사진을 먼저 선택해주세요.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            loadingLayout.visibility = View.VISIBLE // 로딩창 보이게 하기

            // 가상의 '분석' 작업을 위해 3초 (3000 밀리초) 동안 기다립니다.
            Handler(Looper.getMainLooper()).postDelayed({

                // --- DB 저장 로직 (로딩 중에 실행) ---
                val dbHelper = DatabaseHelper(this@SelfDiagnosisActivity)
                val db = dbHelper.writableDatabase

                val values = ContentValues().apply {
                    put(DatabaseHelper.HealthRecordDBEntry.COLUMN_USER_ID, currentUserId)
                    put(
                        DatabaseHelper.HealthRecordDBEntry.COLUMN_IMAGE_PATH,
                        currentImagePath
                    ) // 이제 URI 문자열이 저장됩니다.
                    put(
                        DatabaseHelper.HealthRecordDBEntry.COLUMN_SYMPTOM,
                        tempSymptom
                    ) // 컬럼명 오타 수정 (COLUMN_SYMPTOM -> COLUMN_SYMPTOMS)
                    put(DatabaseHelper.HealthRecordDBEntry.COLUMN_PAIN_LEVEL, tempPainLevel)
                    put(DatabaseHelper.HealthRecordDBEntry.COLUMN_TEMPERATURE, currentTemperature)

                }

                val newRecordId =
                    db.insert(DatabaseHelper.HealthRecordDBEntry.TABLE_NAME, null, values)
                db.close()
                // --- DB 저장 완료 ---

                loadingLayout.visibility = View.GONE // 로딩창 숨기기

                if (newRecordId == -1L) {
                    Toast.makeText(
                        this@SelfDiagnosisActivity,
                        "진단 기록 저장에 실패했습니다.",
                        Toast.LENGTH_SHORT
                    ).show()
                } else {
                    Toast.makeText(this@SelfDiagnosisActivity, "분석이 완료되었습니다!", Toast.LENGTH_SHORT)
                        .show()

                    val intent =
                        Intent(this@SelfDiagnosisActivity, AnalysisResultActivity::class.java)
                    intent.putExtra("RECORD_ID", newRecordId)

                    startActivity(intent)
                    finish()
                }
            }, 3000)
        }
    }
        // --- 블루투스 권한 확인 및 요청 함수 ---
        private fun checkBluetoothPermissions() {
            val permissionsToRequest = ArrayList<String>()

            // Android 12 (API 31) 이상에서 필요한 권한
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) { // S는 Android 12
                if (ContextCompat.checkSelfPermission(
                        this,
                        Manifest.permission.BLUETOOTH_SCAN
                    ) != PackageManager.PERMISSION_GRANTED
                ) {
                    permissionsToRequest.add(Manifest.permission.BLUETOOTH_SCAN)
                }
                if (ContextCompat.checkSelfPermission(
                        this,
                        Manifest.permission.BLUETOOTH_CONNECT
                    ) != PackageManager.PERMISSION_GRANTED
                ) {
                    permissionsToRequest.add(Manifest.permission.BLUETOOTH_CONNECT)
                }
            } else { // Android 11 (API 30) 이하에서 필요한 권한
                // ACCESS_FINE_LOCATION은 블루투스 스캔에 필요하며 런타임 권한입니다.
                if (ContextCompat.checkSelfPermission(
                        this,
                        Manifest.permission.ACCESS_FINE_LOCATION
                    ) != PackageManager.PERMISSION_GRANTED
                ) {
                    permissionsToRequest.add(Manifest.permission.ACCESS_FINE_LOCATION)
                }
                // BLUETOOTH 및 BLUETOOTH_ADMIN은 install time permission으로
                // 매니페스트에 선언하면 보통 자동으로 부여되지만, 확인 차원에서 코드를 남겨둘 수 있습니다.
                // 하지만 Android 6.0 이후로 이들은 런타임 요청 대상이 아닙니다.
                // (즉, 사용자에게 물어보는 팝업은 ACCESS_FINE_LOCATION만 뜹니다)
            }

            if (permissionsToRequest.isNotEmpty()) {
                ActivityCompat.requestPermissions(
                    this,
                    permissionsToRequest.toTypedArray(),
                    REQUEST_BLUETOOTH_PERMISSIONS
                )
            } else {
                // 모든 블루투스 관련 권한이 이미 허용된 상태입니다.
                // 여기에 블루투스 기능을 시작하는 코드를 넣을 수 있습니다.
                startBluetoothOperations()
            }
        }

        // --- 권한 요청 결과 처리 함수 ---
        override fun onRequestPermissionsResult(
            requestCode: Int,
            permissions: Array<String>,
            grantResults: IntArray
        ) {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults)
            if (requestCode == REQUEST_BLUETOOTH_PERMISSIONS) {
                var allPermissionsGranted = true
                for (result in grantResults) {
                    if (result != PackageManager.PERMISSION_GRANTED) {
                        allPermissionsGranted = false
                        break
                    }
                }

                if (allPermissionsGranted) {
                    Toast.makeText(this, "블루투스 권한이 모두 허용되었습니다.", Toast.LENGTH_SHORT).show()
                    // 이제 블루투스 기능을 시작할 수 있습니다.
                    startBluetoothOperations()
                } else {
                    Toast.makeText(this, "블루투스 권한이 거부되어 기능을 사용할 수 없습니다.", Toast.LENGTH_SHORT).show()
                    // 권한이 거부되었으므로 사용자에게 기능 제한을 알리거나 다른 처리를 할 수 있습니다.
                }
            }
        }

        // --- 모든 블루투스 권한이 허용된 후 실행할 함수 ---
        private fun startBluetoothOperations() {
            Toast.makeText(this, "블루투스 기능 준비 완료!", Toast.LENGTH_SHORT).show()
    }
}